export function simple(n, r, t) {
    return (n * r * t) / 100;
};